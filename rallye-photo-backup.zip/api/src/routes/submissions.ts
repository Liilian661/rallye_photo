import { Router, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import multer from 'multer';
import sharp from 'sharp';
import pool from '../config/database';
import { requireAuth, AuthRequest } from '../middleware/auth';
import { emitToEvent } from '../config/socket';
import { uploadToS3, deleteFromS3, getSignedDownloadUrl } from '../utils/s3Service';

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif'];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Format de fichier non supporte'));
    }
  },
});

/**
 * Nettoie un string pour l'utiliser comme nom de dossier S3
 * Supprime accents, caracteres speciaux, espaces -> underscores
 */
function sanitizeForS3(str: string): string {
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // supprime accents
    .replace(/[^a-zA-Z0-9_-]/g, '_') // remplace caracteres speciaux par _
    .replace(/_+/g, '_')             // deduplique les _
    .replace(/^_|_$/g, '')           // trim les _ en debut/fin
    .toLowerCase()
    .slice(0, 80);                   // limite la longueur
}

const router = Router();

// POST /events/:eventId/challenges/:challengeId/submit
router.post('/events/:eventId/challenges/:challengeId/submit', upload.single('photo'), async (req, res: Response): Promise<void> => {
  try {
    const eventId = req.params.eventId as string;
    const challengeId = req.params.challengeId as string;
    const { participantId } = req.body;

    if (!req.file) {
      res.status(400).json({ error: 'Photo manquante' });
      return;
    }

    if (!participantId) {
      res.status(400).json({ error: 'Participant ID manquant' });
      return;
    }

    // Verifier event
    const [eventRows] = await pool.execute(
      'SELECT id, status, deadline, code FROM events WHERE id = ?',
      [eventId]
    );
    if ((eventRows as any[]).length === 0) {
      res.status(404).json({ error: 'Evenement non trouve' });
      return;
    }

    const event = (eventRows as any[])[0];
    if (event.status !== 'active') {
      res.status(403).json({ error: 'Evenement non actif' });
      return;
    }

    if (new Date(event.deadline) < new Date()) {
      res.status(403).json({ error: 'La deadline est depassee' });
      return;
    }

    // Verifier challenge et recuperer le titre pour le dossier S3
    const [challengeRows] = await pool.execute(
      'SELECT id, title FROM challenges WHERE id = ? AND event_id = ?',
      [challengeId, eventId]
    );
    if ((challengeRows as any[]).length === 0) {
      res.status(404).json({ error: 'Defi non trouve' });
      return;
    }
    const challengeTitle = (challengeRows as any[])[0].title;

    // Verifier participant
    const [participantRows] = await pool.execute(
      'SELECT id, name FROM participants WHERE id = ? AND event_id = ?',
      [participantId, eventId]
    );
    if ((participantRows as any[]).length === 0) {
      res.status(404).json({ error: 'Participant non trouve' });
      return;
    }
    const participantName = (participantRows as any[])[0].name;

    // Verifier doublon
    const [existingSubmission] = await pool.execute(
      'SELECT id FROM submissions WHERE challenge_id = ? AND participant_id = ?',
      [challengeId, participantId]
    );
    if ((existingSubmission as any[]).length > 0) {
      res.status(409).json({ error: 'Tu as deja soumis une photo pour ce defi' });
      return;
    }

    // Convertir en WebP avec sharp (qualite 80, max 2000px de large)
    const webpBuffer = await sharp(req.file.buffer)
      .resize({ width: 2000, withoutEnlargement: true })
      .webp({ quality: 80 })
      .toBuffer();

    // Structure S3 : CODE_EVENT/nom_du_defi/nom_participant_uuid.webp
    const id = uuidv4();
    const folderDefi = sanitizeForS3(challengeTitle);
    const fileName = sanitizeForS3(participantName) + '_' + id.slice(0, 8) + '.webp';
    const s3Key = event.code + '/' + folderDefi + '/' + fileName;

    // Upload vers S3
    await uploadToS3(s3Key, webpBuffer, 'image/webp');

    // Generer une URL presignee pour l'affichage immediat
    const photoUrl = await getSignedDownloadUrl(s3Key, 86400); // 24h

    await pool.execute(
      'INSERT INTO submissions (id, event_id, challenge_id, participant_id, photo_url, photo_key) VALUES (?, ?, ?, ?, ?, ?)',
      [id, eventId, challengeId, participantId, photoUrl, s3Key]
    );

    emitToEvent(eventId, 'new-submission', {
      id, challengeId, participantId, participantName, photoUrl,
    });

    // Push to organizer
    res.status(201).json({ id, challengeId, photoUrl });
  } catch (error: any) {
    console.error('Submit photo error:', error);
    if (error.message?.includes('S3 non configure')) {
      res.status(503).json({ error: 'Stockage S3 non configure. Contactez l\'organisateur.' });
    } else {
      res.status(500).json({ error: 'Erreur serveur' });
    }
  }
});

// GET /events/:eventId/submissions
router.get('/events/:eventId/submissions', async (req, res: Response): Promise<void> => {
  try {
    const [rows] = await pool.execute(
      'SELECT s.id, s.challenge_id, s.participant_id, s.photo_url, s.photo_key, s.is_winner, s.submitted_at, p.name as participant_name, c.title as challenge_title FROM submissions s JOIN participants p ON p.id = s.participant_id JOIN challenges c ON c.id = s.challenge_id WHERE s.event_id = ? ORDER BY s.submitted_at DESC',
      [req.params.eventId]
    );

    // Renouveler les URLs presignees
    const submissions = rows as any[];
    for (const sub of submissions) {
      try {
        sub.photo_url = await getSignedDownloadUrl(sub.photo_key, 86400);
      } catch {
        // Garder l'ancienne URL si le S3 n'est pas dispo
      }
    }

    res.json(submissions);
  } catch (error) {
    console.error('List submissions error:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /challenges/:challengeId/submissions
router.get('/challenges/:challengeId/submissions', async (req, res: Response): Promise<void> => {
  try {
    const [rows] = await pool.execute(
      'SELECT s.id, s.participant_id, s.photo_url, s.photo_key, s.is_winner, s.submitted_at, p.name as participant_name FROM submissions s JOIN participants p ON p.id = s.participant_id WHERE s.challenge_id = ? ORDER BY s.submitted_at ASC',
      [req.params.challengeId]
    );

    // Renouveler les URLs presignees
    const submissions = rows as any[];
    for (const sub of submissions) {
      try {
        sub.photo_url = await getSignedDownloadUrl(sub.photo_key, 86400);
      } catch {
        // Garder l'ancienne URL
      }
    }

    res.json(submissions);
  } catch (error) {
    console.error('List challenge submissions error:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// DELETE /submissions/:id
router.delete('/submissions/:id', requireAuth, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const [rows] = await pool.execute(
      'SELECT s.id, s.photo_key, s.event_id FROM submissions s JOIN events e ON e.id = s.event_id WHERE s.id = ? AND e.user_id = ?',
      [req.params.id, req.user!.userId]
    );

    if ((rows as any[]).length === 0) {
      res.status(404).json({ error: 'Soumission non trouvee' });
      return;
    }

    const submission = (rows as any[])[0];

    // Supprimer de S3
    try {
      await deleteFromS3(submission.photo_key);
    } catch (error) {
      console.error('S3 delete error (continuing):', error);
      // On continue quand meme la suppression en BDD
    }

    await pool.execute('DELETE FROM submissions WHERE id = ?', [req.params.id]);
    res.json({ message: 'Photo supprimee' });
  } catch (error) {
    console.error('Delete submission error:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

export default router;