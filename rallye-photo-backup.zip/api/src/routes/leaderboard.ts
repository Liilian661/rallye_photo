import { Router, Response } from 'express';
import pool from '../config/database';

const router = Router();

// GET /events/:eventId/leaderboard
router.get('/events/:eventId/leaderboard', async (req, res: Response): Promise<void> => {
  try {
    const eventId = req.params.eventId as string;

    const [rows] = await pool.execute(
      `SELECT
        p.id,
        p.name,
        COALESCE(SUM(CASE WHEN s.is_winner = TRUE THEN c.points ELSE 0 END), 0) as total_points,
        COUNT(s.id) as total_submissions,
        SUM(CASE WHEN s.is_winner = TRUE THEN 1 ELSE 0 END) as wins
       FROM participants p
       LEFT JOIN submissions s ON s.participant_id = p.id AND s.event_id = ?
       LEFT JOIN challenges c ON c.id = s.challenge_id
       WHERE p.event_id = ?
       GROUP BY p.id, p.name
       ORDER BY total_points DESC, wins DESC, total_submissions DESC`,
      [eventId, eventId]
    );

    const leaderboard = (rows as any[]).map((row: any, index: number) => ({
      rank: index + 1,
      id: row.id,
      name: row.name,
      totalPoints: Number(row.total_points),
      totalSubmissions: Number(row.total_submissions),
      wins: Number(row.wins),
    }));

    res.json(leaderboard);
  } catch (error) {
    console.error('Leaderboard error:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

export default router;
