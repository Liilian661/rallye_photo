import { Router, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import QRCode from 'qrcode';
import pool from '../config/database';
import { requireAuth, AuthRequest } from '../middleware/auth';
import { validateBody } from '../middleware/validateInput';
import { createEventSchema } from '../utils/validators';
import { generateUniqueEventCode } from '../utils/codeGenerator';
import { emitToEvent } from '../config/socket';

const router = Router();

// GET /events
router.get('/', requireAuth, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const [rows] = await pool.execute(
      'SELECT id, name, description, event_date, deadline, code, qr_code_url, gallery_enabled, gallery_locked, status, created_at FROM events WHERE user_id = ? ORDER BY created_at DESC',
      [req.user!.userId]
    );
    res.json(rows);
  } catch (error) {
    console.error('List events error:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// POST /events
router.post('/', requireAuth, validateBody(createEventSchema), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { name, description, eventDate, deadline } = req.body;
    const userId = req.user!.userId;

    const [existingEvents] = await pool.execute(
      'SELECT COUNT(*) as count FROM events WHERE user_id = ?',
      [userId]
    );
    const eventCount = (existingEvents as any[])[0].count;

    const [userRows] = await pool.execute('SELECT plan FROM users WHERE id = ?', [userId]);
    const plan = (userRows as any[])[0]?.plan || 'free';

    const limits: Record<string, number> = { free: 1, starter: 5, pro: 999999 };
    if (eventCount >= (limits[plan] || 1)) {
      res.status(403).json({ error: 'Limite evenements atteinte pour le plan ' + plan });
      return;
    }

    const id = uuidv4();
    const code = await generateUniqueEventCode();
    const joinUrl = (process.env.CLIENT_URL || 'https://app.rallye-photo.com') + '/join/' + code;
    const qrCodeDataUrl = await QRCode.toDataURL(joinUrl, { width: 400, margin: 2 });

    await pool.execute(
      "INSERT INTO events (id, user_id, name, description, event_date, deadline, code, qr_code_url, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')",
      [id, userId, name, description || null, eventDate || null, deadline, code, qrCodeDataUrl]
    );

    res.status(201).json({
      id, name, description, eventDate, deadline, code,
      qrCodeUrl: qrCodeDataUrl, status: 'active',
    });
  } catch (error) {
    console.error('Create event error:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /events/join/:code
router.get('/join/:code', async (req, res: Response): Promise<void> => {
  try {
    const { code } = req.params;

    const [rows] = await pool.execute(
      'SELECT id, name, description, event_date, deadline, code, gallery_enabled, status FROM events WHERE code = ?',
      [code.toUpperCase()]
    );
    const events = rows as any[];

    if (events.length === 0) {
      res.status(404).json({ error: 'Evenement non trouve' });
      return;
    }

    const event = events[0];

    if (event.status === 'archived') {
      res.status(410).json({ error: 'Cet evenement est termine' });
      return;
    }

    res.json({
      id: event.id, name: event.name, description: event.description,
      eventDate: event.event_date, deadline: event.deadline, code: event.code,
      galleryEnabled: event.gallery_enabled, status: event.status,
    });
  } catch (error) {
    console.error('Join event error:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /events/:id
router.get('/:id', requireAuth, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM events WHERE id = ? AND user_id = ?',
      [req.params.id, req.user!.userId]
    );
    const events = rows as any[];

    if (events.length === 0) {
      res.status(404).json({ error: 'Evenement non trouve' });
      return;
    }

    res.json(events[0]);
  } catch (error) {
    console.error('Get event error:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// PATCH /events/:id
router.patch('/:id', requireAuth, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { name, description, eventDate, deadline, galleryEnabled, status } = req.body;
    const fields: string[] = [];
    const values: any[] = [];

    if (name !== undefined) { fields.push('name = ?'); values.push(name); }
    if (description !== undefined) { fields.push('description = ?'); values.push(description); }
    if (eventDate !== undefined) { fields.push('event_date = ?'); values.push(eventDate); }
    if (deadline !== undefined) { fields.push('deadline = ?'); values.push(deadline); }
    if (galleryEnabled !== undefined) { fields.push('gallery_enabled = ?'); values.push(galleryEnabled); }
    if (status !== undefined) { fields.push('status = ?'); values.push(status); }

    if (fields.length === 0) {
      res.status(400).json({ error: 'Aucune modification' });
      return;
    }

    values.push(req.params.id, req.user!.userId);

    await pool.execute(
      'UPDATE events SET ' + fields.join(', ') + ' WHERE id = ? AND user_id = ?',
      values
    );

    res.json({ message: 'Evenement mis a jour' });
  } catch (error) {
    console.error('Update event error:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// DELETE /events/:id
router.delete('/:id', requireAuth, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    // TODO: Delete S3 photos for this event
    await pool.execute(
      'DELETE FROM events WHERE id = ? AND user_id = ?',
      [req.params.id, req.user!.userId]
    );
    res.json({ message: 'Evenement supprime' });
  } catch (error) {
    console.error('Delete event error:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

export default router;
