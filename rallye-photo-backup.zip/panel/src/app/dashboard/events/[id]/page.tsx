'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import api from '@/lib/api';
import { IconCamera, IconArrowLeft, IconX, IconChevronLeft, IconChevronRight } from '@/lib/icons';
import { io, Socket } from 'socket.io-client';

interface Event {
  id: string;
  name: string;
  description: string;
  event_date: string;
  deadline: string;
  code: string;
  qr_code_url: string;
  status: string;
}

interface Challenge {
  id: string;
  title: string;
  description: string;
  points: number;
  status: string;
  is_surprise: boolean;
  vote_enabled: number;
  vote_closed: number;
}

interface Submission {
  id: string;
  challenge_id: string;
  participant_id: string;
  participant_name: string;
  challenge_title: string;
  photo_url: string;
  is_winner: boolean;
  submitted_at: string;
}

export default function EventDetailPage() {
  const params = useParams();
  const router = useRouter();
  const eventId = params.id as string;
  const socketRef = useRef<Socket | null>(null);

  const [event, setEvent] = useState<Event | null>(null);
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);

  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPoints, setNewPoints] = useState(10);
  const [showAddChallenge, setShowAddChallenge] = useState(false);
  const [previewIndex, setPreviewIndex] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'defis' | 'galerie'>('defis');

  const loadData = useCallback(async () => {
    try {
      const [eventRes, challengesRes, submissionsRes] = await Promise.all([
        api.get(`/events/${eventId}`),
        api.get(`/events/${eventId}/challenges`),
        api.get(`/events/${eventId}/submissions`),
      ]);
      setEvent(eventRes.data);
      setChallenges(challengesRes.data);
      setSubmissions(submissionsRes.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [eventId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // WebSocket - real-time updates
  useEffect(() => {
    if (!eventId) return;

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'https://api.rallye-photo.com', {
      transports: ['websocket', 'polling'],
    });

    socket.on('connect', () => {
      socket.emit('join-event', eventId);
    });

    // Listen to ALL events for real-time refresh
    socket.on('new-submission', () => loadData());
    socket.on('participant-joined', () => loadData());
    socket.on('challenge-started', () => loadData());
    socket.on('winner-selected', () => loadData());
    socket.on('winner-revealed', () => loadData());
    socket.on('leaderboard-updated', () => loadData());
    socket.on('vote-enabled', () => loadData());
    socket.on('vote-closed', () => loadData());
    socket.on('vote-cast', () => loadData());

    socketRef.current = socket;

    return () => {
      socket.emit('leave-event', eventId);
      socket.disconnect();
    };
  }, [eventId, loadData]);

  const addChallenge = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.post(`/events/${eventId}/challenges`, {
        title: newTitle,
        description: newDesc || null,
        points: newPoints,
      });
      setNewTitle('');
      setNewDesc('');
      setNewPoints(10);
      setShowAddChallenge(false);
      loadData();
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur');
    }
  };

  const selectWinner = async (challengeId: string, submissionId: string) => {
    try {
      await api.post(`/challenges/${challengeId}/winner/${submissionId}`);
      loadData();
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur');
    }
  };

  const revealWinner = async (challengeId: string) => {
    try {
      await api.post(`/challenges/${challengeId}/reveal`);
      alert('Gagnant revele en live !');
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur');
    }
  };

  const deleteChallenge = async (challengeId: string) => {
    if (!confirm('Supprimer ce defi ?')) return;
    try {
      await api.delete(`/challenges/${challengeId}`);
      loadData();
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur');
    }
  };

  const deleteEvent = async () => {
    if (!confirm('Supprimer cet evenement et toutes ses donnees ?')) return;
    try {
      await api.delete(`/events/${eventId}`);
      router.push('/dashboard/events');
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur');
    }
  };

  const enableVote = async (challengeId: string) => {
    try {
      await api.post(`/challenges/${challengeId}/enable-vote`);
      loadData();
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur');
    }
  };

  const closeVote = async (challengeId: string) => {
    if (!confirm('Fermer le vote et designer le gagnant automatiquement ?')) return;
    try {
      await api.post(`/challenges/${challengeId}/close-vote`);
      loadData();
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur');
    }
  };

  // Keyboard navigation for lightbox
  useEffect(() => {
    if (previewIndex === null) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setPreviewIndex(null);
      if (e.key === 'ArrowRight' && previewIndex < submissions.length - 1) setPreviewIndex(previewIndex + 1);
      if (e.key === 'ArrowLeft' && previewIndex > 0) setPreviewIndex(previewIndex - 1);
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [previewIndex, submissions.length]);

  if (loading) return <p style={{ color: 'var(--rp-text-muted)' }}>Chargement...</p>;
  if (!event) return <p style={{ color: 'var(--rp-text-primary)' }}>Evenement non trouve</p>;

  const isPastDeadline = event.deadline ? new Date(event.deadline).getTime() < Date.now() : false;

  // Lightbox with navigation
  const lightbox = previewIndex !== null && submissions[previewIndex] ? (
    <div
      onClick={() => setPreviewIndex(null)}
      style={{
        position: 'fixed',
        top: 0, left: 0, right: 0, bottom: 0,
        background: 'rgba(0,0,0,0.9)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000,
        cursor: 'pointer',
        padding: '2rem',
      }}
    >
      {previewIndex > 0 && (
        <button
          onClick={(e) => { e.stopPropagation(); setPreviewIndex(previewIndex - 1); }}
          style={{
            position: 'absolute',
            left: 16, top: '50%', transform: 'translateY(-50%)',
            background: 'rgba(255,255,255,0.15)',
            border: 'none', color: '#fff',
            fontSize: 28, width: 48, height: 48,
            borderRadius: '50%', cursor: 'pointer',
          }}
        >
          <IconChevronLeft size={28} />
        </button>
      )}

      <div onClick={(e) => e.stopPropagation()} style={{ textAlign: 'center', maxWidth: '85%' }}>
        <img
          src={submissions[previewIndex].photo_url}
          alt={submissions[previewIndex].participant_name}
          style={{
            maxWidth: '100%',
            maxHeight: '80vh',
            borderRadius: 12,
            objectFit: 'contain',
          }}
        />
        <div style={{ marginTop: 12, color: '#fff' }}>
          <p style={{ fontSize: 16, fontWeight: 600 }}>
            {submissions[previewIndex].participant_name}
            {submissions[previewIndex].is_winner && (
              <span style={{ color: 'var(--rp-accent)', marginLeft: 8 }}>GAGNANT</span>
            )}
          </p>
          <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)', marginTop: 2 }}>
            {submissions[previewIndex].challenge_title}
          </p>
          <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>
            {previewIndex + 1} / {submissions.length}
          </p>
        </div>
      </div>

      {previewIndex < submissions.length - 1 && (
        <button
          onClick={(e) => { e.stopPropagation(); setPreviewIndex(previewIndex + 1); }}
          style={{
            position: 'absolute',
            right: 16, top: '50%', transform: 'translateY(-50%)',
            background: 'rgba(255,255,255,0.15)',
            border: 'none', color: '#fff',
            fontSize: 28, width: 48, height: 48,
            borderRadius: '50%', cursor: 'pointer',
          }}
        >
          <IconChevronRight size={28} />
        </button>
      )}

      <button
        onClick={() => setPreviewIndex(null)}
        style={{
          position: 'absolute',
          top: 16, right: 16,
          background: 'rgba(255,255,255,0.15)',
          border: 'none', color: '#fff',
          fontSize: 24, width: 40, height: 40,
          borderRadius: '50%', cursor: 'pointer',
        }}
      >
        <IconX size={24} />
      </button>
    </div>
  ) : null;

  return (
    <div className="fade-in">
      {lightbox}

      {/* Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: '1.5rem',
      }}>
        <div>
          <button
            onClick={() => router.back()}
            className="btn-ghost"
            style={{ marginBottom: 8, display: 'flex', alignItems: 'center', gap: 4 }}
          >
            <IconArrowLeft size={14} /> Retour
          </button>
          <h2 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 28,
            fontWeight: 700,
            letterSpacing: '-0.02em',
            color: 'var(--rp-text-primary)',
          }}>
            {event.name}
          </h2>
          <p style={{ fontSize: 13, color: 'var(--rp-text-muted)', marginTop: 4 }}>
            Code : <span style={{
              fontWeight: 700,
              color: 'var(--rp-accent)',
              fontSize: 16,
            }}>{event.code}</span>
            {' \u00B7 '}
            Deadline : {event.deadline ? new Date(event.deadline).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }) : '-'}
            {isPastDeadline && (
              <span style={{ color: 'var(--rp-danger-text)', fontWeight: 600 }}> (expiree)</span>
            )}
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span className={`badge ${event.status === 'active' && !isPastDeadline ? 'badge-success' : 'badge-muted'}`}
            style={{ padding: '6px 16px', fontSize: 13 }}>
            {isPastDeadline ? 'Expire' : event.status === 'active' ? 'Actif' : event.status}
          </span>
          {!isPastDeadline && (
            <button
              onClick={deleteEvent}
              style={{
                background: 'var(--rp-danger-light)',
                color: 'var(--rp-danger-text)',
                border: 'none',
                borderRadius: 50,
                padding: '6px 16px',
                fontSize: 12,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              Supprimer
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20 }}>
        <button
          onClick={() => setActiveTab('defis')}
          style={{
            padding: '8px 22px',
            borderRadius: 50,
            border: 'none',
            fontSize: 13,
            fontWeight: 600,
            cursor: 'pointer',
            background: activeTab === 'defis' ? 'var(--rp-accent)' : 'var(--rp-bg-card)',
            color: activeTab === 'defis' ? 'var(--rp-accent-text)' : 'var(--rp-text-muted)',
          }}
        >
          Defis ({challenges.length})
        </button>
        <button
          onClick={() => setActiveTab('galerie')}
          style={{
            padding: '8px 22px',
            borderRadius: 50,
            border: 'none',
            fontSize: 13,
            fontWeight: 600,
            cursor: 'pointer',
            background: activeTab === 'galerie' ? 'var(--rp-accent)' : 'var(--rp-bg-card)',
            color: activeTab === 'galerie' ? 'var(--rp-accent-text)' : 'var(--rp-text-muted)',
          }}
        >
          Galerie ({submissions.length})
        </button>
      </div>

      {/* ==================== DEFIS TAB ==================== */}
      {activeTab === 'defis' && (
        <div className="event-detail-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 24 }}>
          <div>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '1rem',
            }}>
              <h3 style={{
                fontFamily: 'var(--font-display)',
                fontSize: 20,
                fontWeight: 600,
                color: 'var(--rp-text-primary)',
              }}>
                Defis
              </h3>
              <button
                className="btn-primary"
                onClick={() => setShowAddChallenge(!showAddChallenge)}
                style={{ fontSize: 13, padding: '8px 20px' }}
              >
                + Ajouter
              </button>
            </div>

            {showAddChallenge && (
              <div className="card" style={{ marginBottom: 16, padding: '1.25rem' }}>
                <form onSubmit={addChallenge}>
                  <div style={{ marginBottom: 12 }}>
                    <input type="text" className="input-field" placeholder="Titre du defi" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} required />
                  </div>
                  <div style={{ marginBottom: 12 }}>
                    <input type="text" className="input-field" placeholder="Description (optionnel)" value={newDesc} onChange={(e) => setNewDesc(e.target.value)} />
                  </div>
                  <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <label style={{ fontSize: 13, color: 'var(--rp-text-secondary)' }}>Points :</label>
                      <input type="number" className="input-field" value={newPoints} onChange={(e) => setNewPoints(parseInt(e.target.value) || 10)} min={1} max={1000} style={{ width: 80 }} />
                    </div>
                    <button type="submit" className="btn-primary" style={{ fontSize: 13, padding: '8px 20px' }}>Creer</button>
                    <button type="button" className="btn-ghost" onClick={() => setShowAddChallenge(false)}>Annuler</button>
                  </div>
                </form>
              </div>
            )}

            {challenges.length === 0 ? (
              <div className="card" style={{ textAlign: 'center', padding: '2rem' }}>
                <p style={{ color: 'var(--rp-text-muted)', fontSize: 14 }}>Aucun defi pour le moment</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {challenges.map((challenge) => {
                  const challengeSubmissions = submissions.filter(s => s.challenge_id === challenge.id);
                  const winner = challengeSubmissions.find(s => s.is_winner);

                  return (
                    <div key={challenge.id} className="card">
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                        <div>
                          <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 600, color: 'var(--rp-text-primary)' }}>
                            {challenge.title}
                          </h4>
                          {challenge.description && (
                            <p style={{ fontSize: 13, color: 'var(--rp-text-muted)', marginTop: 2 }}>{challenge.description}</p>
                          )}
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span className="badge badge-accent">{challenge.points} pts</span>
                          <button onClick={() => deleteChallenge(challenge.id)} className="btn-ghost" style={{ display: 'flex', alignItems: 'center' }}><IconX size={16} /></button>
                        </div>
                      </div>

                      {challengeSubmissions.length > 0 && (
                        <div style={{ borderTop: '0.5px solid var(--rp-border)', paddingTop: 12, marginTop: 8 }}>
                          <p style={{ fontSize: 12, color: 'var(--rp-text-muted)', marginBottom: 10 }}>
                            {challengeSubmissions.length} photo(s) soumise(s)
                            {winner && (
                              <span style={{ color: 'var(--rp-success-text)', fontWeight: 600 }}>
                                {' \u00B7 '}Gagnant : {winner.participant_name}
                              </span>
                            )}
                          </p>

                          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 10, marginBottom: 8 }}>
                            {challengeSubmissions.map((sub) => {
                              const globalIndex = submissions.findIndex(s => s.id === sub.id);
                              return (
                                <div key={sub.id} style={{
                                  borderRadius: 10,
                                  border: sub.is_winner ? '2px solid var(--rp-accent)' : '1.5px solid var(--rp-border)',
                                  overflow: 'hidden',
                                  background: 'var(--rp-bg-card)',
                                  position: 'relative',
                                }}>
                                  <img src={sub.photo_url} alt={sub.participant_name} loading="lazy"
                                    onClick={() => setPreviewIndex(globalIndex)}
                                    style={{ width: '100%', height: 140, objectFit: 'cover', cursor: 'pointer', display: 'block' }}
                                  />
                                  {!!!!sub.is_winner && (
                                    <div style={{ position: 'absolute', top: 6, right: 6, background: 'var(--rp-accent)', color: 'var(--rp-accent-text)', fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 50 }}>
                                      GAGNANT
                                    </div>
                                  )}
                                  <div style={{ padding: '8px 10px' }}>
                                    <p style={{ fontSize: 12, fontWeight: 600, color: 'var(--rp-text-primary)', marginBottom: 4 }}>{sub.participant_name}</p>
                                    {isPastDeadline && !winner && !!!challenge.vote_enabled && (
                                      <button onClick={() => selectWinner(challenge.id, sub.id)} style={{
                                        width: '100%', padding: '4px 8px', borderRadius: 6, border: 'none',
                                        background: 'var(--rp-accent)', color: 'var(--rp-accent-text)',
                                        fontSize: 11, fontWeight: 700, cursor: 'pointer',
                                      }}>
                                        Choisir
                                      </button>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>

                          {isPastDeadline && !winner && !!!challenge.vote_enabled && !!!challenge.vote_closed && challengeSubmissions.length >= 2 && (
                            <div style={{ marginTop: 8 }}>
                              <button onClick={() => enableVote(challenge.id)} style={{
                                padding: '6px 16px', borderRadius: 50,
                                border: '1.5px solid var(--rp-secondary)', background: 'var(--rp-secondary-light)',
                                color: 'var(--rp-secondary-text)', fontSize: 12, fontWeight: 600, cursor: 'pointer',
                              }}>
                                Activer le vote du public
                              </button>
                            </div>
                          )}

                          {!!!!challenge.vote_enabled && !!!challenge.vote_closed && !winner && (
                            <div style={{
                              marginTop: 8, padding: '10px 14px', borderRadius: 10,
                              background: 'var(--rp-secondary-light)',
                              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                            }}>
                              <p style={{ fontSize: 12, fontWeight: 600, color: 'var(--rp-secondary-text)' }}>Vote en cours...</p>
                              <button onClick={() => closeVote(challenge.id)} style={{
                                padding: '5px 14px', borderRadius: 50, border: 'none',
                                background: 'var(--rp-secondary)', color: '#fff',
                                fontSize: 11, fontWeight: 700, cursor: 'pointer',
                              }}>
                                Fermer le vote
                              </button>
                            </div>
                          )}

                          {winner && challenge.status === 'judged' && (
                            <button className="btn-gradient" onClick={() => revealWinner(challenge.id)}
                              style={{ fontSize: 13, padding: '6px 18px', marginTop: 4 }}>
                              Reveler en live
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* QR Code sidebar */}
          <div>
            <div className="card" style={{ textAlign: 'center', position: 'sticky', top: '2rem' }}>
              <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 600, marginBottom: 12, color: 'var(--rp-text-primary)' }}>
                QR Code
              </h4>
              {event.qr_code_url && (
                <img src={event.qr_code_url} alt="QR Code" style={{ width: '100%', maxWidth: 200, margin: '0 auto 12px', display: 'block', borderRadius: 12 }} />
              )}
              <p style={{ fontSize: 22, fontWeight: 700, color: 'var(--rp-accent)', fontFamily: 'var(--font-display)', letterSpacing: '0.1em', marginBottom: 8 }}>
                {event.code}
              </p>
              <p style={{ fontSize: 12, color: 'var(--rp-text-muted)' }}>Partagez ce code ou le QR code a vos invites</p>
              <div style={{ marginTop: 16 }}>
                <button
                onClick={() => {
                  const url = `${process.env.NEXT_PUBLIC_APP_URL || 'https://app.rallye-photo.com'}/join/${event.code}`;
                  navigator.clipboard.writeText(url);
                  alert('Lien copie !');
                }}
                className="btn-secondary"
                style={{ fontSize: 12, padding: '6px 16px', width: '100%' }}
              >
                Copier le lien
              </button>
              <button
                onClick={() => {
                  const url = `${process.env.NEXT_PUBLIC_APP_URL || 'https://app.rallye-photo.com'}/join/${event.code}`;
                  if (navigator.share) {
                    navigator.share({ title: event.name, text: 'Rejoins le rallye photo !', url });
                  } else {
                    navigator.clipboard.writeText(url);
                    alert('Lien copie !');
                  }
                }}
                className="btn-gradient"
                style={{ fontSize: 12, padding: '6px 16px', width: '100%', marginTop: 8 }}
              >
                Partager
              </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== GALERIE TAB ==================== */}
      {activeTab === 'galerie' && (
        <div>
          {submissions.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
              <div style={{ marginBottom: 8 }}><IconCamera size={36} color="var(--rp-text-muted)" /></div>
              <p style={{ color: 'var(--rp-text-muted)', fontSize: 15 }}>Aucune photo pour le moment</p>
            </div>
          ) : (
            <>
              <p style={{ fontSize: 13, color: 'var(--rp-text-muted)', marginBottom: 16 }}>
                {submissions.length} photo(s) au total {' \u00B7 '}Cliquez pour agrandir {' \u00B7 '}Fleches clavier pour naviguer
              </p>

              {challenges.map((challenge) => {
                const subs = submissions.filter(s => s.challenge_id === challenge.id);
                if (subs.length === 0) return null;

                return (
                  <div key={challenge.id} style={{ marginBottom: 28 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 600, color: 'var(--rp-text-primary)' }}>
                        {challenge.title}
                      </h3>
                      <span className="badge badge-accent">{challenge.points} pts</span>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 12 }}>
                      {subs.map((sub) => {
                        const globalIndex = submissions.findIndex(s => s.id === sub.id);
                        return (
                          <div key={sub.id} onClick={() => setPreviewIndex(globalIndex)} style={{
                            borderRadius: 12, border: sub.is_winner ? '2px solid var(--rp-accent)' : '1px solid var(--rp-border)',
                            overflow: 'hidden', background: 'var(--rp-bg-card)', cursor: 'pointer', position: 'relative',
                          }}>
                            <img src={sub.photo_url} alt={sub.participant_name} loading="lazy"
                              style={{ width: '100%', height: 200, objectFit: 'cover', display: 'block' }} />
                            {!!!!sub.is_winner && (
                              <div style={{ position: 'absolute', top: 8, right: 8, background: 'var(--rp-accent)', color: 'var(--rp-accent-text)', fontSize: 10, fontWeight: 700, padding: '3px 10px', borderRadius: 50 }}>
                                GAGNANT
                              </div>
                            )}
                            <div style={{ padding: '10px 12px' }}>
                              <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--rp-text-primary)' }}>{sub.participant_name}</p>
                              <p style={{ fontSize: 11, color: 'var(--rp-text-muted)', marginTop: 2 }}>
                                {new Date(sub.submitted_at).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </>
          )}
        </div>
      )}
    </div>
  );
}
