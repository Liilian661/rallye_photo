'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import api from '@/lib/api';

export default function NewEventPage() {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [deadline, setDeadline] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // datetime-local retourne l'heure locale de l'utilisateur (ex: "2025-06-15T18:00")
      // On la convertit en ISO UTC pour que l'API stocke toujours en UTC
      const deadlineUTC = new Date(deadline).toISOString();
      const eventDateUTC = eventDate ? new Date(eventDate + 'T00:00:00').toISOString() : null;

      const { data } = await api.post('/events', {
        name,
        description: description || null,
        eventDate: eventDateUTC,
        deadline: deadlineUTC,
      });
      router.push(`/dashboard/events/${data.id}`);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Erreur lors de la création');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 560 }} className="fade-in">
      <h2 style={{
        fontFamily: 'var(--font-display)',
        fontSize: 28,
        fontWeight: 700,
        letterSpacing: '-0.02em',
        marginBottom: '2rem',
        color: 'var(--rp-text-primary)',
      }}>
        Nouvel événement
      </h2>

      <div className="card" style={{ padding: '2rem' }}>
        <form onSubmit={handleSubmit}>
          {error && (
            <div className="alert-error" style={{ marginBottom: '1rem' }}>
              {error}
            </div>
          )}

          <div style={{ marginBottom: '1rem' }}>
            <label style={{
              display: 'block',
              fontSize: 13,
              fontWeight: 500,
              color: 'var(--rp-text-secondary)',
              marginBottom: 6,
            }}>
              Nom de l&apos;événement *
            </label>
            <input
              type="text"
              className="input-field"
              placeholder="Ex: Mariage de Sophie & Thomas"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label style={{
              display: 'block',
              fontSize: 13,
              fontWeight: 500,
              color: 'var(--rp-text-secondary)',
              marginBottom: 6,
            }}>
              Description (optionnel)
            </label>
            <textarea
              className="input-field"
              placeholder="Décrivez votre événement..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              style={{ resize: 'vertical' }}
            />
          </div>

          <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.5rem' }}>
            <div style={{ flex: 1 }}>
              <label style={{
                display: 'block',
                fontSize: 13,
                fontWeight: 500,
                color: 'var(--rp-text-secondary)',
                marginBottom: 6,
              }}>
                Date de l&apos;événement
              </label>
              <input
                type="date"
                className="input-field"
                value={eventDate}
                onChange={(e) => setEventDate(e.target.value)}
              />
            </div>
            <div style={{ flex: 1 }}>
              <label style={{
                display: 'block',
                fontSize: 13,
                fontWeight: 500,
                color: 'var(--rp-text-secondary)',
                marginBottom: 6,
              }}>
                Deadline des photos *
              </label>
              <input
                type="datetime-local"
                className="input-field"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                required
              />
            </div>
          </div>

          <div style={{ display: 'flex', gap: 12 }}>
            <button
              type="submit"
              className="btn-gradient"
              disabled={loading}
            >
              {loading ? 'Création...' : 'Créer l\'événement'}
            </button>
            <button
              type="button"
              className="btn-secondary"
              onClick={() => router.back()}
            >
              Annuler
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}