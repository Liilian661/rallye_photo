'use client';

import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'next/navigation';
import api from '@/lib/api';
import { getParticipant } from '@/lib/participant';
import { IconTrophy } from '@/lib/icons';
import { io } from 'socket.io-client';

interface LeaderboardEntry {
  rank: number;
  id: string;
  name: string;
  totalPoints: number;
  totalSubmissions: number;
  wins: number;
}

export default function LeaderboardPage() {
  const params = useParams();
  const eventId = params.id as string;

  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [participantId, setParticipantId] = useState('');

  useEffect(() => {
    const p = getParticipant(eventId);
    if (p) setParticipantId(p.id);
  }, [eventId]);

  const loadLeaderboard = useCallback(async () => {
    try {
      const { data } = await api.get(`/events/${eventId}/leaderboard`);
      setLeaderboard(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [eventId]);

  useEffect(() => {
    loadLeaderboard();
  }, [loadLeaderboard]);

  // WebSocket for real-time updates
  useEffect(() => {
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'https://api.rallye-photo.com', {
      transports: ['websocket', 'polling'],
    });

    socket.on('connect', () => {
      socket.emit('join-event', eventId);
    });

    socket.on('leaderboard-updated', () => loadLeaderboard());
    socket.on('winner-selected', () => loadLeaderboard());

    return () => {
      socket.emit('leave-event', eventId);
      socket.disconnect();
    };
  }, [eventId, loadLeaderboard]);

  const getRankClass = (rank: number) => {
    if (rank === 1) return 'rank-1';
    if (rank === 2) return 'rank-2';
    if (rank === 3) return 'rank-3';
    return 'rank-other';
  };

  const getRankEmoji = (rank: number) => {
    if (rank === 1) return '1';
    if (rank === 2) return '2';
    if (rank === 3) return '3';
    return `${rank}`;
  };

  return (
    <div className="page-container page-with-nav fade-in">
      <div style={{ textAlign: 'center', marginBottom: 24 }}>
        <h1 style={{
          fontFamily: 'var(--font-display)',
          fontSize: 24,
          fontWeight: 700,
          letterSpacing: '-0.02em',
          marginBottom: 4,
        }}>
          <span style={{ display: 'inline-flex', verticalAlign: 'middle', marginRight: 6 }}><IconTrophy size={22} color="var(--rp-gold)" /></span>Classement
        </h1>
        <p style={{ fontSize: 13, color: 'var(--rp-text-muted)' }}>
          En temps réel
        </p>
      </div>

      {loading ? (
        <p style={{ textAlign: 'center', color: 'var(--rp-text-muted)' }}>
          Chargement...
        </p>
      ) : leaderboard.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '2rem' }}>
          <div style={{ marginBottom: 8 }}><IconTrophy size={36} color="var(--rp-text-muted)" /></div>
          <p style={{ color: 'var(--rp-text-muted)', fontSize: 15 }}>
            Aucun classement pour le moment
          </p>
          <p style={{ color: 'var(--rp-text-muted)', fontSize: 13, marginTop: 4 }}>
            Le classement apparaîtra quand l&apos;organisateur
            désignera les gagnants
          </p>
        </div>
      ) : (
        <div className="card" style={{ padding: '0.5rem' }}>
          {leaderboard.map((entry) => {
            const isMe = entry.id === participantId;

            return (
              <div
                key={entry.id}
                className="leaderboard-row"
                style={{
                  background: isMe ? 'var(--rp-pink-light)' : undefined,
                  border: isMe ? '1.5px solid var(--rp-pink)' : '1.5px solid transparent',
                  borderRadius: 16,
                }}
              >
                {/* Rank */}
                <div
                  className={`rank-badge ${getRankClass(entry.rank)}`}
                  style={{ fontSize: entry.rank <= 3 ? 18 : 14 }}
                >
                  {getRankEmoji(entry.rank)}
                </div>

                {/* Name */}
                <div style={{ flex: 1 }}>
                  <p style={{
                    fontWeight: isMe ? 700 : 500,
                    fontSize: 15,
                    color: isMe ? 'var(--rp-pink)' : 'var(--rp-text)',
                  }}>
                    {entry.name} {isMe && '(vous)'}
                  </p>
                  <p style={{ fontSize: 12, color: 'var(--rp-text-muted)' }}>
                    {entry.totalSubmissions} photo{entry.totalSubmissions > 1 ? 's' : ''}
                    {entry.wins > 0 && ` · ${entry.wins} victoire${entry.wins > 1 ? 's' : ''}`}
                  </p>
                </div>

                {/* Points */}
                <div style={{ textAlign: 'right' }}>
                  <p style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 20,
                    fontWeight: 700,
                    color: entry.totalPoints > 0 ? 'var(--rp-blue)' : 'var(--rp-text-muted)',
                  }}>
                    {entry.totalPoints}
                  </p>
                  <p style={{ fontSize: 10, color: 'var(--rp-text-muted)' }}>pts</p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
